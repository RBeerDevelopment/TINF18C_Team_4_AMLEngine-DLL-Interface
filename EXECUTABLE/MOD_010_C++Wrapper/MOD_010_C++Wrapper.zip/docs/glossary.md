# Glossary

| Term   |      Explanation      |
|----------|---|
| vs |  Visual Studio Community / Enterprise |
| PM |  (Nuget)  packet manager   |
| cmd |  command-line interpreter|

