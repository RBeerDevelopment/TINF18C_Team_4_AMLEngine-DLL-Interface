# Common Warnings

### Error about false .Net Version

Add manually the correct .Net version.
See in [Capitel 4](4_compiling.md#4-project-compiler-settings---runtime) for more information.
