These are the standard AutomationML communication libraries according to whitepaper part 5.

Additionally, this folder contains all libraries and library extensions according to:
From IEC 62714-1 to IEC 62714-4.

