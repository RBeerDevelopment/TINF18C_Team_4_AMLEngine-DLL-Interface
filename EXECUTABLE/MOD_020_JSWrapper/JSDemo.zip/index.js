// import des wrappers
var wrapper = require("amlenginewrapper");

// Datei die verwendet werden soll
var file = "fehler.aml";

// validieren einer Beispieldatei
// wrapper.validate(file);

// reparieren der Beispieldatei
// wrapper.repair(file);

// Erstellen einer neuen InstanceHierarchy mit einem Element
// wrapper.appendToInstanceHierarchy(file, "TestHierarchy", "TestElement");

// Rename Testelement in TestHierarchy to TestABCDEFGElement
// wrapper.renameElement(file, "TestHierarchy", "TestABCDEFGElement", "TestElement");