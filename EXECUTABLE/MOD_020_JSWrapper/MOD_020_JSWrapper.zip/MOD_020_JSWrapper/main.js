wrapper = require('./AMLEngineWrapper.js');

function logResult(result) {
    console.log(`Call returned: ${result}`);
}

wrapper.validate("./exampleFiles/fehler.aml", logResult());
